**Notes**
1. tasks on port 8000: `lsof -t -i :8000`
2. kill the process by pid: `kill -15 <PID>`
